from .mashumaronone import *

__doc__ = mashumaronone.__doc__
if hasattr(mashumaronone, "__all__"):
    __all__ = mashumaronone.__all__